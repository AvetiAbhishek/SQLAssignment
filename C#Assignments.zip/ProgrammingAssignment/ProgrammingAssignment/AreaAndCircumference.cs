﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingAssignment
{
    public class AreaAndCircumference
    {

        double r, Area_Circle;
        double Circumference_Circle;
        double PI = 3.14;

        public void Calculate()
        {
            Console.WriteLine("Input the radius of the circle : ");
            r = Convert.ToDouble(Console.ReadLine());
            Area_Circle =  PI * r*r;
            Console.WriteLine("Area of Circle : {0}",Area_Circle);
           


            Console.WriteLine("Input the radius of the circle : ");
            r  = Convert.ToDouble(Console.ReadLine());
            Circumference_Circle = 2 * PI * r;
            Console.WriteLine("Circumference of Circle :" + Circumference_Circle);

            Console.ReadKey();


        }

        static void Main()
        {
            AreaAndCircumference objArea = new AreaAndCircumference();
            objArea.Calculate();

            AreaAndCircumference objCir = new AreaAndCircumference();  
            objCir.Calculate();


        }

    }
    
    

  
}


