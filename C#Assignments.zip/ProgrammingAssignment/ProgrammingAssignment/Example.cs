﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProgrammingAssignment
{
    public class Example
    {

        public void SumIntegers()
        {
            int[] array = new int[] {1,2,3,4,5};

            int sum = 0;
            Array.ForEach(array, i => sum += i);



            Console.WriteLine("sum of integers:{0}",sum);
            Console.Read();

        }
        public static void Main()
        {
            Example objExample = new Example();
            objExample.SumIntegers();
            


        }
     
    }

}
