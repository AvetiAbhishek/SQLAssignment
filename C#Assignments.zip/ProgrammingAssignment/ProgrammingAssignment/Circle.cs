﻿using System;

public class Circle
{
    public static void Main()
    {

       
    }
}
