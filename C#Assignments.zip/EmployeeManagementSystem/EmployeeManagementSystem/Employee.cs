﻿using System;
using System.Collections;

namespace EmployeeManagementSystem
{
class Employee
    {
        
           private int EmpNo; 
           private string EmpName;
           private double Salary;
           private double HRA;
           private double TA;
           private double DA;
           private double PF;
           private double TDS;
           private double NetSalary;
           private double GrossSalary;

        public void AcceptEmpDetails() 
        {

            Console.WriteLine("enter the EmpNo :");
            EmpNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter the EmpName: ");
            EmpName = Convert.ToString(Console.ReadLine());

            Console.WriteLine("entere the Salary:");
            Salary = Convert.ToDouble(Console.ReadLine());
            // Console.ReadLine();


        }  

        //creating a constructor to intialize the fields
        public Employee(int empNo, string empName, double sal)
        {
            EmpNo = empNo;
            EmpName = empName;
            Salary = sal;

            

            if (Salary < 5000)
            {
                HRA = Salary * 10 / 100;
                TA = Salary * 5 / 100;
                DA = Salary * 15 / 100;
                GrossSalary = Salary + HRA + TA + DA;
            }
            else if (Salary < 10000)
            {
                HRA = Salary * 15 / 100;
                TA = Salary * 10 / 100;
                DA = Salary * 20 / 100;
                GrossSalary = Salary + HRA + TA + DA;

            }
            else if (Salary < 15000)
            {
                HRA = Salary * 20 / 100;
                TA = Salary * 15 / 100;
                DA = Salary * 25 / 100;
                GrossSalary = Salary + HRA + TA + DA;

            }
            else if (Salary < 20000)
            {
                HRA = Salary * 25 / 100;
                TA = Salary * 20 / 100;
                DA = Salary * 30 / 100;
                GrossSalary = Salary + HRA + TA + DA;

            }
            else if (Salary >= 20000)
            {

                HRA = Salary * 30 / 100;
                TA = Salary * 25 / 100;
                DA = Salary * 35 / 100;
                GrossSalary = Salary + HRA + TA + DA;
            }


        




        }
        //creating a method CalculateSalary

        public void CalculateSalary()
        {

            PF = GrossSalary*10/100;
            TDS = GrossSalary*18/100;
            NetSalary = GrossSalary-(PF+TDS);


        }
        public double GrossSal
        {
            get { return GrossSalary; }
        }

        static void Main(string[] args)
        {
              Employee Emp1 = new Employee(1,"ABHISHEK",7000);
              //Emp1.AcceptEmpDetails();
              Emp1.CalculateSalary();
              Console.WriteLine("Gross Salary of Employee is :"+Emp1.GrossSalary);
              Console.WriteLine("NetSalary of Employe is :"+Emp1.NetSalary);

            //using  Arraylist to hold more than one employee (ASG 5)
             ArrayList l = new ArrayList();
             Console.WriteLine("enter the employee names to array :");
             l.Add("Abhi");
             l.Add("Aish");
             l.Add("akhil");
            


             foreach(object emp in l)
              {
                  Console.WriteLine(emp);
              }

            

            Console.ReadKey();

        }
        


    }
}
