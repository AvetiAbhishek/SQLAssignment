﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeManagementSystem1
{
    public delegate void EmployeeDelegate();
    public class Employee
    {
        protected int EmpNo;
        protected string EmpName;
        protected double Salary;
        protected double HRA;
        protected double TA;
        protected double DA;
        protected double PF;
        protected double TDS;
        protected double NetSalary;
        protected double GrossSalary;

        public virtual double GrossSal()
        {
            if (Salary < 5000)
            {
                HRA = Salary * 10 / 100;
                TA = Salary * 5 / 100;
                DA = Salary * 15 / 100;
                GrossSalary = ((Salary) + (HRA + TA + DA));
            }
            else if (Salary < 10000)
            {
                HRA = Salary * 15 / 100;
                TA = Salary * 10 / 100;
                DA = Salary * 20 / 100;
                GrossSalary = ((Salary) + (HRA + TA + DA));
            }
            else if (Salary < 15000)
            {
                HRA = Salary * 20 / 100;
                TA = Salary * 15 / 100;
                DA = Salary * 25 / 100;
                GrossSalary = ((Salary) + (HRA + TA + DA));
            }
            else if (Salary < 20000)
            {
                HRA = Salary * 25 / 100;
                TA = Salary * 20 / 100;
                DA = Salary * 30 / 100;
                GrossSalary = ((Salary) + (HRA + TA + DA));
            }
            else if (Salary >= 20000)
            {
                HRA = Salary * 25 / 100;
                TA = Salary * 20 / 100;
                DA = Salary * 35 / 100;
                GrossSalary = ((Salary) + (HRA + TA + DA));
            }
            return GrossSalary;
        }
        public virtual void CalculateSalary()
        {
            PF = (GrossSalary / 100) * 10;
            TDS = (GrossSalary / 100) * 18;
        }

        public void DisplayDetails()
        {

        }

    }
   
    public class MarketingExecutive : Employee
    {
        private int Kilometer;
        private int TravelAllowence;
        private int TelephoneAllowence;

        public override double GrossSal()
        {
            base.GrossSal();

            TravelAllowence = Kilometer * 5;
            TelephoneAllowence = 1000;
            GrossSalary += TravelAllowence + TelephoneAllowence;
            return GrossSalary;
        }

        public override void CalculateSalary()
        {
            base.CalculateSalary();
            NetSalary = (GrossSalary - (TDS + PF));

        }
        public new void DisplayDetails()
        {
            Console.WriteLine("enter MarketingExecutive id");
            EmpNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter MarketingExecutive name");
            EmpName = Console.ReadLine();
            Console.WriteLine("enter MarketingExecutive salary");
            Salary = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("enter kilometers travelled by employee");
            Kilometer = Convert.ToInt32(Console.ReadLine());
            GrossSal();
            CalculateSalary();
            Console.WriteLine("employeeGrossSalary {0}", GrossSalary);
            Console.WriteLine("employeeNetSalary {0}", NetSalary);
        }
    }
    class MulticastDeligate
    {
        static void Main()
        {

           MarketingExecutive marketingExecutive = new MarketingExecutive();


            EmployeeDelegate employeeDelegate = new EmployeeDelegate(marketingExecutive.DisplayDetails);
            employeeDelegate += marketingExecutive.DisplayDetails;


            employeeDelegate.Invoke();

        }
    }
}