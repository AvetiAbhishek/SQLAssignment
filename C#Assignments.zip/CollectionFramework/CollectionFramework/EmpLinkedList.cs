﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionFramework
{
    internal class EmpLinkedList
    {

        static void Main(string[] args)
        {
            
            LinkedList<String> list = new LinkedList<String>();
            Console.WriteLine("Adding Employee Details");
            list.AddFirst("Abhishek"); //a) adding a new employee in the starting of linked list
            list.AddLast("Aish");   //a) adding a new employee at the end of the list
            list.AddLast("Akhil");  //a) adding a new employee
            list.AddLast("vinith");   //a) adding a new employee
            list.AddLast("Ram");   //a) adding a new employee

            foreach (String item in list)   //b) displaying a list of employees using foreach loop
            {
                Console.WriteLine("Newly added employee details : {0} ", item);
            }
           
            Console.WriteLine(list.Contains("Abhishek"));   //performing specific search operation (true/false)
            Console.WriteLine(list.Contains("Aish"));  //performing specific search operation (true/false)
            
            //c)total number of employees in the list/Count of employees
            Console.WriteLine("Total number of employees in the linked list is : {0} ", list.Count);

            Console.ReadKey();
           
        }
    }
}
