﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionFramework
{
    public class UserException
    {
        int[] arr;
        int top;
        int max;
        public UserException(int Size)
        {
            arr = new int[Size];
            top = -1;
            max = Size;

        }

        

        public void Push(int item)
        {
            try
            {
                if (top == max - 1)
                {
                    throw new StackException ("User defined Exception:Stack overflow");
                    return;
                }
                else
                {
                    arr[++top] = item;
                }
            }
            catch (Exception e)
            {

            }
        }

        public int Pop()
        {

            
                if (top == -1)
                {
                    throw new StackException("Stack Underflow");
                    return -1;
                }
                else
                {
                    Console.WriteLine("Poped element is: " + arr[top]);
                    return arr[top--];
                }
            
           

        }

        public void PrintMyStack()
        {   
            if (top == -1)
            {
                throw new StackException("Stack is Empty");
                return;
            }
            else
            {
                for (int i = 0; i <= top; i++)
                {
                    Console.WriteLine("The added elements are :" + arr[i]);

                }
                Console.WriteLine("-----------------------");
            }
        }

        class StackException : Exception
        {
            public StackException(String message) : base(message)
            {
                Console.WriteLine(message);
            }

        }


        static void Main()
        {
            UserException S = new UserException(3);
            S.Push(10);
            S.Push(20);
            S.Push(30);
            S.Push(40);
            S.Push(50);




            Console.WriteLine("Items are : ");
            S.PrintMyStack();

            S.Pop();
            S.Pop();
            S.Pop();
            S.Pop();

            Console.ReadKey();
        }

    }
}
