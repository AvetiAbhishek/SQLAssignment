﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CollectionFramework
{
    public class Genneric
    {
        static void Main()
        {
            int[] a = new int[5];
            Console.WriteLine("Enter number of elements in array :");

            /*copy in array
            int[] b = new int[5];
             for (int i = 0; i < a.Length; i++)
             {
                 Console.WriteLine(a[i]);
             }*/



            string s = Console.ReadLine();
            int x = Int32.Parse(s);
            Console.WriteLine("\n Enter array elements \n");

            for (int i = 0; i < x; i++)
            {
                string s1 = Console.ReadLine();
                a[i] = Int32.Parse(s1);
            }

            // Sort the values of the Array.  
            Array.Sort(a);
            Console.WriteLine("The elements are sorted");
            for (int i = 0; i < x; i++)
            {

                Console.WriteLine($"Element {i + 1} is {a[i]}");
            }


            // Reverse the values of the Array.  
            Array.Reverse(a);
            Console.WriteLine("Reversed");
            for (int i = 0; i < x; i++)
            {

                Console.WriteLine($"Element {i + 1} is {a[i]}");
            }

        }
    }
}
