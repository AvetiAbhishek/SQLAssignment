﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace InheritanceandPolymorphism
{
    class FileIO
    {
        
        const string fileName = "example.txt";

        static void Write()
        {
            StreamWriter sw = new StreamWriter(fileName);
            sw.WriteLine("This is abhi");
            string s = "welcome";
            sw.WriteLine(s);
            sw.Close();
        }
        static void Read()
        {
            StreamReader sr = new StreamReader(fileName);
            string s = sr.ReadToEnd();
            Console.WriteLine(s);
            sr.Close();

        }
       
        static void Main(String[] args)
        {
            Write();
            Console.ReadLine();

        }

    }
}
