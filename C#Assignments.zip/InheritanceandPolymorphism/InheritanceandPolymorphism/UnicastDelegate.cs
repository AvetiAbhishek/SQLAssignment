﻿using System;


namespace InheritanceandPolymorphism
{
    //Defining delegate 
    public delegate double GrossDelegate();
    public delegate void DisplayDelegate();



    public class Employee
        {
            protected int EmpNo;
            protected string EmpName;
            protected double Salary;
            protected double HRA;
            protected double TA;
            protected double DA;
            protected double PF;
            protected double TDS;
            protected double NetSalary;
            protected double GrossSalary;

            public virtual double GrossSal()
            {
                if (Salary < 5000)
                {
                    HRA = Salary * 10 / 100;
                    TA = Salary * 5 / 100;
                    DA = Salary * 15 / 100;
                    GrossSalary = ((Salary) + (HRA + TA + DA));
                }
                else if (Salary < 10000)
                {
                    HRA = Salary * 15 / 100;
                    TA = Salary * 10 / 100;
                    DA = Salary * 20 / 100;
                    GrossSalary = ((Salary) + (HRA + TA + DA));
                }
                else if (Salary < 15000)
                {
                    HRA = Salary * 20 / 100;
                    TA = Salary * 15 / 100;
                    DA = Salary * 25 / 100;
                    GrossSalary = ((Salary) + (HRA + TA + DA));
                }
                else if (Salary < 20000)
                {
                    HRA = Salary * 25 / 100;
                    TA = Salary * 20 / 100;
                    DA = Salary * 30 / 100;
                    GrossSalary = ((Salary) + (HRA + TA + DA));
                }
                else if (Salary >= 20000)
                {
                    HRA = Salary * 25 / 100;
                    TA = Salary * 20 / 100;
                    DA = Salary * 35 / 100;
                    GrossSalary = ((Salary) + (HRA + TA + DA));
                }
                return GrossSalary;
            }
            public virtual void CalculateSalary()
            {
                PF = (GrossSalary / 100) * 10;
                TDS = (GrossSalary / 100) * 18;
            
            }

            public void DisplayDetails()
            {
                
            }

        }
        class Manager : Employee
        {
            private double PetrolAllowance;
            private double FoodAllowance;
            private double OtherAllowance;

            public override double GrossSal()
            {
                base.GrossSal();
                PetrolAllowance = Salary * 8 / 100;
                FoodAllowance = Salary * 13 / 100;
                OtherAllowance = Salary * 3 / 100;
                GrossSalary += (PetrolAllowance + FoodAllowance + OtherAllowance);

                return GrossSalary;
            }

            public override void CalculateSalary()
            {
                base.CalculateSalary();
                NetSalary = (GrossSalary - (TDS + PF));

            }
            public new void DisplayDetails()
            {
                Console.WriteLine("enter manager id");
                EmpNo = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter manger name");
                EmpName = Console.ReadLine();
                Console.WriteLine("enter manger salary");
                Salary = Convert.ToInt32(Console.ReadLine());
                GrossSal();
                CalculateSalary();
                Console.WriteLine("MangerGrossSalary {0}", GrossSalary);
                Console.WriteLine("MangerNetSalary {0}", NetSalary);
            }

        }

        class Client1
        {
            static void Main()
            {
                Manager manager = new Manager();
            //instantiating the delegates for Grossdel and calculatedel
                GrossDelegate gd = new GrossDelegate(manager.GrossSal);

                //invoking the methods
                gd.Invoke();

                DisplayDelegate dd = new DisplayDelegate(manager.DisplayDetails);
                dd.Invoke();

            

            Console.ReadLine();
            }
        }
    
}
