﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InheritanceandPolymorphism
{
    public  class MyStack
    {
        int[] arr;
        int top;
        int max;
        public MyStack(int Size)
        {
            arr = new int[Size];
            top = -1;
            max = Size;

        }

        
        public void Push(int item)
        {
            if (top == max - 1)
            {
                Console.WriteLine("Stack overflow");
                return;
            }
            else
            {
                arr[++top] = item;
            }
        }

        public int Pop()
        {
            
                if (top == -1)
                {
                    Console.WriteLine("Stack Underflow");
                    return -1;
                }
                else
                {
                    Console.WriteLine("Poped element is: " + arr[top]);
                    return arr[top--];
                }
            
            

        }

        public void PrintMyStack()
        {
            if (top == -1)
            {
                Console.WriteLine("Stack is Empty");
                return;
            }
            else
            {
                for (int i = 0; i <= top; i++)
                {
                    Console.WriteLine("The added elements are :"+ arr[i]);
                    
                }
                Console.WriteLine("-----------------------");
            }
        }






        static void Main()
        {
            MyStack S = new MyStack(3);
            S.Push(10);
            S.Push(20);
            S.Push(30);
            S.Push(40);
            S.Push(50);
            
            


            Console.WriteLine("Items are : ");
            S.PrintMyStack();

            S.Pop();
            S.Pop();
            S.Pop();
            S.Pop();

            Console.ReadKey();
        }
        
    }
   
}
