USE Assignment
/* creating customer table with id as primary key and FirstName as Not NUll  */
CREATE TABLE Customer (
ID int primary key ,
FirstName nvarchar(40) NOT NULL ,
LastName nvarchar(40) ,
City nvarchar(40) ,
Country nvarchar(40),
Phone nvarchar(20) ,
);
/* creating index named IndexCustomerName */

CREATE INDEX IndexCustomerName on Customer(FirstName) ;

/* TO see indexes*/
EXEC sp_helpindex 'dbo.Customer'
GO

/*creating order table*/
CREATE TABLE [order]
(
ID int primary key ,
OrderDate datetime NOT NULL ,
OrderNumber nvarchar(40),
CustomerID int foreign key references Customer(ID),
TotalAmount decimal(12,2) ,
  );
/*creating index for order table*/
CREATE INDEX IndexOrderCustomerID on [Order](ID) ;
CREATE INDEX IndexOrderOrderDate on [Order](OrderDate) ;

EXEC sp_helpindex 'dbo.Order'
GO

/*creating order item table with ID as primary key orderID and productID as foreign key */
CREATE TABLE OrderItem
(ID int primary key ,
OrderID int foreign key references [order](ID) ,
ProductID  int foreign key references Customer(ID) ,
UnitPrice decimal(12,2),
Quantity int ,
);

/*creating index on OrderItem table */
CREATE INDEX IndexOrderItemOrderId on OrderItem(OrderID) ;
CREATE INDEX IndexOrderItemProductId on OrderItem(ProductID) ;

EXEC sp_helpindex 'dbo.OrderItem'
GO 

/*creating Product table with ID as primary key*/
CREATE TABLE Product
(ID int primary key ,
ProductName nvarchar(40) ,
UnitPrice decimal(12,2) ,
Package nvarchar(30) ,
IsDiscontinued bit ,
);

/*creating index on Product table*/
CREATE INDEX IndexProductSupplierId on Product(ID) ;
CREATE INDEX IndexProductName on Product(ProductName) ;

EXEC sp_helpindex 'dbo.Product'
GO


/*Inserting Records in all tables */

INSERT INTO Customer VALUES 
(1 , 'Abhi' ,'Aveti', 'Hyderabad' ,'India' ,9550333276) ,
(2,'Sameer' , 'Syed' , 'Vijaywada' ,'India' ,885544666) ,
(3,'Uday' , 'Kumar' , 'Warangal' ,'India' ,8877445596) ,
(4,'Balram' , 'yadav' , 'Kakinada' ,'India' ,8877445596) ,
(5,'Sumanth' , 'Yadav' , 'Kakinada' ,'India' ,8877445596) ;

SELECT * FROM Customer

/*Inserting Records in Order Table */

INSERT INTO [order] VALUES
(1,'2022-05-29 06:03:41','123',5,1500.36) ,
(2,'2022-04-21 05:02:42','234',4,1600.36) ,
(3,'2022-03-12 04:01:43','345',3,1700.36) ,
(4,'2022-02-13 03:02:44','567',2,1800.36) ,
(5,'2022-01-16 01:04:45','789',1,1900.36) ;

DELETE FROM [order] 

SELECT * FROM [order]

/*Inserting Records in OrderItem Table */
INSERT INTO OrderItem VALUES
(1,16,5,45000.75,35) ,
(2,13,7,25000.00,25) ,
(3,14,5,26000.23,45) ,
(4,13,8,27000.74,55) ,
(5,16,9,28000.33,65) ;

EXEC sp_help 'dbo.OrderItem'


/*Inserting Records in Product Table */
INSERT INTO Product VALUES
(1,'samsungA50' ,1400.26,' paperboard' ,0) ,
(2,'Redmi' ,1400.26,'plastic ' ,1)  ,
(3,'Oneplus' ,1400.26,'molded fibers' ,0)  ,
(4,'Iphone' ,1400.26,'  folding cartons' ,1) ,
(5,'Nokia' ,1400.26,' rigid boxes' ,0) ;

SELECT * FROM Product

/*. Display the details from Customer table who is from country India*/
SELECT * FROM Customer
where Country = 'India' ;

SELECT FirstName From Customer
where FirstName like '_A%';

/* DISPLAY WHOSE NAME THIRD LETTER IS 'Y'*/
SELECT Customer.FirstName,Customer.LastName
FROM Customer 
WHERE LastName LIKE '_y%';




/*creating a Employee table*/

CREATE TABLE Employee(
EmployeeId int IDENTITY(1,1) PRIMARY KEY,
FirstName nvarchar(40),
LastName nvarchar(40),
City nvarchar(40),
Country nvarchar(40),
Phone nvarchar(40),);

SELECT * FROM Employee;

/*inserting values into table*/

INSERT INTO dbo.Employee(FirstName,LastName,City,Country,Phone)
VALUES ('SAI','ABHILASH','VIZAG','INDIA','8639293390'),
('PAVAN','KUMAR','MUMBAI','INDIA','8639293390'),
('SAI','RAHUL','CHEENAI','UK','030-0074321'),
('RAM','CHARN','BANGALORE','GERMANY','7894561230'),
('SURESH','RAINA','PUNE','INDIA','1234567890');

/*Display FirstName,LastName from table*/
SELECT FirstName,LastName from Employee;

/*select order Details where unit price is greater than 10 and less than 20*/
SELECT * FROM OrderItem
WHERE UnitPrice > 10 AND UnitPrice < 20

/*. Display order details which contains shipping date and arrange the order by date*/
SELECT OrderDate AS SHIPPING_DATE 
FROM [Order]
ORDER BY OrderDate ASC

/* Print the products supplied by 'plastic'*/
SELECT * FROM Product
WHERE Package ='plastic'

SELECT * FROM Product

/* print the average quantity ordered for every product*/
SELECT AVG(Quantity) AS Avg_Quantity
FROM OrderItem
GROUP BY OrderID

SELECT * FROM Customer;





























	   


