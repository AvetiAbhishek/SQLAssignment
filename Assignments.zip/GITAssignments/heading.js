// How to create variables:
var x;
let y;
