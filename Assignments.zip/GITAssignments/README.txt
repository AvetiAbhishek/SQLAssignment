The Assignment is regarding HTML,CSS,JS 

