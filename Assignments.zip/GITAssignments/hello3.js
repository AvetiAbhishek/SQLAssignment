// How to use variables:
x = 5;
y = 6;
let z = x + y;